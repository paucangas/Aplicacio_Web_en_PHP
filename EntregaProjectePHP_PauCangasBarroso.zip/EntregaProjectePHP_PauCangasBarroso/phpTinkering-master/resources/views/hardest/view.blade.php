<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game Details</title>
</head>
<body>
<h1>Game Details</h1>
<p>Name: <?= htmlspecialchars($game->name) ?></p>
<p>Developer: <?= htmlspecialchars($game->developer) ?></p>
<p>Release Year: <?= htmlspecialchars($game->release_year) ?></p>
<p>Difficulty: <?= htmlspecialchars($game->difficulty) ?></p>
<a href="/HardestGamesIndex">Back to Games</a>
</body>
</html>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hardest Games</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-8">
<div class="max-w-lg mx-auto bg-white shadow-md rounded-lg p-6">
    <h1 class="text-3xl font-bold mb-4">Edit Hardest Game</h1>
    <form action="/update" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($game->id) ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
        <div class="mb-4">
            <label for="name" class="block text-gray-700">Game Name:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($game->name) ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2" required>
        </div>
        <div class="mb-4">
            <label for="developer" class="block text-gray-700">Developer:</label>
            <input type="text" name="developer" value="<?= htmlspecialchars($game->developer) ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2" required>
        </div>
        <div class="mb-4">
            <label for="release_year" class="block text-gray-700">Release Year:</label>
            <input type="number" name="release_year" value="<?= htmlspecialchars($game->release_year) ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2" required>
        </div>
        <div class="mb-4">
            <label for="difficulty">Difficulty:</label>
            <input type="text" id="difficulty" name="difficulty" value="<?= htmlspecialchars($game->difficulty) ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2" required>
        </div>
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700">Edit</button>
    </form>
    <a href="/HardestGamesIndex" class="text-gray-500 hover:underline mt-4 block">Return</a>
</div>
</body>
</html>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>No s'ha trobat la pàgina</title>
</head>
<body>
    <h1>
        404 - No s'ha trobat la pàgina
    </h1>
    <p>La pàgina que busques no existeix</p>
    <p>
        <a href="/">Tornar a la pàgina principal</a>
    </p>
</body>
</html>
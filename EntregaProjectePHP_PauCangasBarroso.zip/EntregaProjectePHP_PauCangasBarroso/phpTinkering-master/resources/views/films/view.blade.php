<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Film Details</title>
</head>
<body>
<h1>Film Details</h1>
<p>Title: <?= htmlspecialchars($film->name) ?></p>
<p>Director: <?= htmlspecialchars($film->director) ?></p>
<p>Year: <?= htmlspecialchars($film->year) ?></p>
<a href="/films">Back to Films</a>
</body>
</html>
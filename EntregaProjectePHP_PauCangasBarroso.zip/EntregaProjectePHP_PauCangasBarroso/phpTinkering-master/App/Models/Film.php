<?php

namespace App\Models;

use Core\App;
use PDO;

class Film
{
    protected static $table = 'films';

    //funcio per a que torne totes les pelis
    public static function getAll()
    {
        $db = App::get('database');
        $statement = $db->getConnection()->prepare('SELECT * FROM ' . self::$table);
        $statement->execute();
        return $statement->fetchAll();
    }

    //funcio per a buscar una peli
    public static function find($id)
    {
        $db = App::get('database')->getConnection();
        $statement = $db->prepare('SELECT * FROM ' . self::$table . ' WHERE id = :id');
        $statement->execute(array('id' => $id));
        return $statement->fetch(\PDO::FETCH_OBJ);
    }

    //funcio create
    public static function create($data)
    {
        $db = App::get('database')->getConnection();
        $nextId = self::getNextId();
        $statement = $db->prepare('INSERT INTO '. static::$table . "(id, name, director, year) VALUES (:id, :name, :director, :year)");
        $statement->bindValue(':id', $nextId);
        $statement->bindValue(':name', $data['name']);
        $statement->bindValue(':director', $data['director']);
        $statement->bindValue(':year', $data['year']);
        $statement->execute();
    }

    //funcio update
    public static function update($id, $data)
    {
        $db = App::get('database')->getConnection();
        $statement = $db->prepare("UPDATE ". static::$table . " SET name = :name, director = :director, year = :year WHERE id = :id");
        $statement->bindValue(':id', $id);
        $statement->bindValue(':name', $data['name']);
        $statement->bindValue(':director', $data['director']);
        $statement->bindValue(':year', $data['year']);
        $statement->execute();
    }

    //funcio delete
    public static function delete($id)
    {
        $db = App::get('database')->getConnection();
        $statement = $db->prepare('DELETE FROM '. static::$table . ' WHERE id = :id');
        $statement->bindValue(':id', $id);
        $statement->execute();
    }

    public static function getNextId()
    {
        $db = App::get('database')->getConnection();
        $statement = $db->prepare('SELECT id FROM ' . static::$table . ' ORDER BY id ASC');
        $statement->execute();
        $ids = $statement->fetchAll(PDO::FETCH_COLUMN);

        $nextId = 1;
        foreach ($ids as $id) {
            if ($id != $nextId) {
                break;
            }
            $nextId++;
        }

        return $nextId;
    }
}
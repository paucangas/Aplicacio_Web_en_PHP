<?php

namespace App\Models;

use Core\App;
use PDO;

class HardestGames
{
    // Taula de la base de dades per als jocs difícils
    protected static $table = 'hardestgames';

    // Funció per obtenir tots els jocs difícils
    public static function getAll()
    {
        $db = App::get('database');
        $statement = $db->getConnection()->prepare('SELECT * FROM ' . self::$table);
        $statement->execute();
        return $statement->fetchAll();
    }

    // Funció per trobar un joc difícil pel seu ID
    public static function find($id)
    {
        $db = App::get('database')->getConnection();
        $statement = $db->prepare('SELECT * FROM ' . self::$table . ' WHERE id = :id');
        $statement->execute(['id' => $id]);
        return $statement->fetch(\PDO::FETCH_OBJ);
    }

    // Funció per crear un nou joc difícil
    public static function create($data)
    {
        $db = App::get('database')->getConnection();
        $nextId = self::getNextId();
        $statement = $db->prepare('INSERT INTO '. static::$table . "(id, name, developer, release_year, difficulty) VALUES (:id, :name, :developer, :release_year, :difficulty)");
        $statement->bindValue(':id', $nextId);
        $statement->bindValue(':name', $data['name']);
        $statement->bindValue(':developer', $data['developer']);
        $statement->bindValue(':release_year', $data['release_year']);
        $statement->bindValue(':difficulty', $data['difficulty']);
        $statement->execute();
    }

    // Funció per actualitzar un joc difícil existent
    public static function update($id, $data)
    {
        $db = App::get('database')->getConnection();
        $statement = $db->prepare("UPDATE ". static::$table . " SET name = :name, developer = :developer, release_year = :release_year, difficulty = :difficulty WHERE id = :id");
        $statement->bindValue(':id', $id);
        $statement->bindValue(':name', $data['name']);
        $statement->bindValue(':developer', $data['developer']);
        $statement->bindValue(':release_year', $data['release_year']);
        $statement->bindValue(':difficulty', $data['difficulty']);
        $statement->execute();
    }

    // Funció per eliminar un joc difícil
    public static function delete($id)
    {
        $db = App::get('database')->getConnection();
        $statement = $db->prepare('DELETE FROM '. static::$table . ' WHERE id = :id');
        $statement->bindValue(':id', $id);
        $statement->execute();
    }

    public static function getNextId()
    {
        $db = App::get('database')->getConnection();
        $statement = $db->prepare('SELECT id FROM ' . static::$table . ' ORDER BY id ASC');
        $statement->execute();
        $ids = $statement->fetchAll(PDO::FETCH_COLUMN);

        $nextId = 1;
        foreach ($ids as $id) {
            if ($id != $nextId) {
                break;
            }
            $nextId++;
        }

        return $nextId;
    }
}
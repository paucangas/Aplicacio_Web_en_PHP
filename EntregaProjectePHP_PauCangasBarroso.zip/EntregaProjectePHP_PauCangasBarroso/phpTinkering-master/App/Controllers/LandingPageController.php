<?php

namespace App\Controllers;

class LandingPageController
{
    public function index()
    {
        require __DIR__ . '/../../resources/views/landing_page.blade.php';
    }
}
<?php

namespace App\Controllers;

use App\Models\HardestGames;

class HardestGamesController
{
    // Funció index per llistar tots els jocs
    public function index()
    {
        // Obtenim tots els jocs
        $games = HardestGames::getAll();

        // Passem els jocs a la vista
        return view('hardest/index', ['games' => $games]);
    }

    // Funció per anar a la vista de creació de nous jocs
    public function create()
    {
        return view('hardest/create');
    }

    // Funció per guardar un nou joc i tornar a la vista principal
    public function store()
    {
        $data = $_POST;
        HardestGames::create($data);
        header('location: /HardestGamesIndex');
        exit;
    }

    // Funció per a la vista d'edició d'un joc
    public function edit($id)
    {
        $game = HardestGames::find($id);
        return view('hardest/edit', ['game' => $game]);
    }

    // Funció update per modificar el joc a la base de dades
    public function update($id, $data)
    {
        $data = $_POST;
        HardestGames::update($id, $data);
        header('location: /HardestGamesIndex');
        exit;
    }

    // Funció per anar a la vista d'eliminació d'un joc
    public function delete($id)
    {
        $game = HardestGames::find($id);
        return view('hardest/delete', ['game' => $game]);
    }

    // Funció per eliminar un joc de la base de dades
    public function destroy($id)
    {
        HardestGames::delete($id);
        header('location: /HardestGamesIndex');
        exit;
    }

    public function view($id)
    {
        $game = HardestGames::find($id);
        require __DIR__ . '/../../resources/views/hardest/view.blade.php';
    }
}
?>
